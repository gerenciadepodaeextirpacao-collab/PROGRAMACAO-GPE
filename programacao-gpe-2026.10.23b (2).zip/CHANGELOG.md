# Programação GPE — o que mudou

Versão atual: 2026.10.23b

## 2026.10.23b (23/10/2026)

- Checklist: baixar vários checklists ou várias comunicações de defeito num PDF só (um por página), por dia, semana, mês ou todos, para todas as turmas, PODA I, PODA II ou uma turma
- Fotos e vídeo do checklist e da manutenção abrem direto do Supabase (não dependem mais do redirecionamento do netlify.toml) e saem no PDF
- camada-gpe.js mudou: suba junto com o index.html
- Troca de senha obrigatória no primeiro acesso e sempre que a gerência redefinir a senha: a pessoa cria uma senha só dela antes de entrar
- Aba Atualizar (só gerente): links do app no Netlify e no Claude, do GitHub, do Netlify e do Supabase, com botão de copiar
- Aba Atualizar: arquivos prontos para o GitHub (index.html, camada-gpe.js e netlify.toml já ligados ao Supabase); o .zip traz os arquivos soltos
- Tela de entrada no Netlify mostra o motivo quando não conecta ao banco (camada-gpe.js ausente, chave recusada, banco vazio ou sem internet)
- camada-gpe.js novo (Supabase): suba junto com o index.html

## 2026.10.23 (23/10/2026)

- Relatório: gráficos da evolução semanal, mensal e anual (poda em colunas 3D e extirpação em linha, e locais atendidos por tipo em linhas)
- Relatório: tabelas de evolução semanal, mensal e anual no modelo da planilha (semana, período, poda total, extirpação total, processo/O.S, entre-pista, praça…), com o histórico da planilha até a 32ª semana
- Baixar em PDF os gráficos da manutenção, com os filtros escolhidos e o logo da COMURG
- Gráficos da manutenção: incidência de defeito por equipamento (quantas vezes estragou), tempo em manutenção (total, média e maior parada), disponibilidade no período, intervalo médio entre defeitos e defeito mais comum
- Gráficos (aba dentro do Checklist) só da comunicação de defeito / manutenção, em 3D com linhas de grade: comunicações e retornos por dia com a linha de equipamentos em manutenção, tipo de defeito, urgência, parado × operante, por equipamento, por turma e dias fora de operação
- Comunicação de defeito: parte 7 "Retorno à atividade" para preencher quando o equipamento voltar (data, horário, KM, oficina, serviço executado, liberado para operar, devolução do reserva e assinatura do supervisor); a comunicação em aberto mostra o botão para registrar o retorno
- Fotos e vídeo só pela câmera, tirados na hora: o app recusa arquivo antigo da galeria
- Comunicação de defeito: 6 fotos obrigatórias (2 do defeito em ângulos diferentes, parte de cima da carroceria, dentro do cesto e as duas laterais do equipamento inteiro); as fotos saem no PDF
- Checklist: fotos obrigatórias da parte de cima da carroceria e de dentro do cesto (limpos) e das duas laterais do caminhão, e vídeo curto 360° do cesto; as fotos saem no PDF

## 2026.10.22 (22/10/2026)

- Serviço a executar também obrigatório em O.S e processo
- Serviço "Poda de rebaixamento de copa" passou a se chamar "Poda de redução de copa"
- Serviço "Poda de levantamento de copa" trocado por "Poda de levantamento de saia"
- Serviços "Árvore caída" e "Galho caído" na lista de serviços a executar
- Programar: em entre-pista, praça e área pública é obrigatório especificar o serviço (poda de manutenção, poda/extirpação, limpeza, levantamento de saia, adequação à rede, redução de copa, emergência, extirpação ou outro); aparece nas listas, no relatório e na planilha
- Programar: O.S e processo não bloqueiam entre-pista, praça, área pública e calçada no mesmo endereço (e essas não bloqueiam O.S e processo); a duplicidade vale só entre O.S/processo ou entre os demais tipos
- Checklist por equipamento: PODA I faz 2 por período e PODA II faz 4 (3 equipamentos + a van); a aba mostra quantos cada turma já fez no dia e o formulário sugere o equipamento que falta
- Checklist e comunicação de defeito: assinatura sempre do supervisor da turma (entrega, recebimento, comunicação e retorno); gerência e coordenação podem preencher e o supervisor assina no aparelho com a matrícula e a senha de assinatura dele; diretoria só consulta
- Baixar em PDF o checklist e a comunicação de defeito já preenchidos, no layout do formulário COMURG, com as assinaturas eletrônicas
- Recebimento do turno: quem recebe vê o checklist na própria aba (aviso com número na aba Checklist), confere e assina dando ciência das condições do equipamento
- Botão de olho em todos os campos de senha (entrar, acessos, assinatura) para ver o que está sendo digitado
- Comunicação de defeito e recolhimento para manutenção do cesto aéreo (formulário COMURG completo), assinada pelo supervisor, com registro do retorno do equipamento e lista de manutenções em aberto; pode ser aberta direto do checklist com os dados já preenchidos
- Checklist: assinatura eletrônica no modelo de documento assinado (selo, nome, cargo, data e hora e código verificador), com senha própria de assinatura, diferente da senha de entrar; o gerente pode apagar uma senha de assinatura esquecida
- Checklist: item dos cones pergunta se o equipamento está com os cones oferecidos pela empresa MAAS
- Aba Checklist: checklist diário de inspeção pós-operacional do cesto aéreo (formulário COMURG completo: situação do equipamento, conferência final, ocorrências e declaração), com aviso de equipamento não apto e das equipes que trabalharam no dia sem checklist
- Checklist assinado pelo supervisor que entrega e pelo supervisor que recebe o turno (operador identificado por nome e matrícula); depois de recebido, o checklist fica fechado
- Tipo de local Processo de volta (junto com O.S), com nº obrigatório; o endereço fica bloqueado até o processo ser concluído

## 2026.10.21 (21/10/2026)

- Endereço em campos separados: tipo de via (R., AV., AL.…), nome, QD., LT., complemento e setor; o app monta o logradouro no padrão
- Endereço padronizado: R. (rua), AV. (avenida), AL. (alameda), QD. (quadra), LT. (lote); o app corrige ao sair do campo e não salva fora do padrão
- Duplicidade: O.S em aberto bloqueia até ser concluída; área pública, canteiro central e praça executados ficam bloqueados para outra supervisão por 180 dias
- Aviso de duplicidade mostra a supervisão, o supervisor, a equipe, a data e quem lançou a programação, já enquanto o endereço é digitado
- Bloqueio de duplicidade reforçado: endereço com programação aberta ou já atendido nos últimos 60 dias (por qualquer equipe) não pode ser programado de novo (compara a rua mesmo com quadra/lote diferentes)
- Escala 12x36 retirada do app e do relatório (meta diária vale de segunda a sábado)
- Contrato semanal = contrato mensal ÷ 4, comparado com a programação e a execução da semana (Painel e relatório)
- Painel sem o quadro de movimentação recente
- Meta de programação diária: R$ 50 mil por supervisão
- Somas corrigidas: no período, o programado conta pela data programada e o executado pela data em que foi feito (inclui serviços adiantados)
- Relatório: itens do contrato com quantidade e valor (R$) em cada barra
- PDF do relatório sem cortes: página inteira na largura (corrigido corte do lado esquerdo), blocos não se dividem entre páginas e tabelas longas repetem o cabeçalho
- Semanas mostram o período: de segunda a domingo (ex.: Semana 33ª · de 19/10 a 25/10/2026)
- Baixas e Quedas: ver todas as turmas juntas, por grupo (PODA I / PODA II) ou uma turma separada
- Localização pelo GPS do aparelho na baixa, no serviço sem programação e nas quedas (com opção de colar coordenadas)
- Nomes dos supervisores corrigidos conforme o cadastro de Acessos
- Supervisor vê só os registros de galho e árvore caída da própria turma
- Gerente pode excluir programação pela Lista e pelo Painel (com confirmação)
- Aba Atualizar (só gerente): baixar tudo num único .zip, arquivos avulsos e o que mudou
- Painel: evolução semanal, mensal e anual e resumo mês a mês
- Painel: acompanhamento da programação (turma × dia) e movimentação recente
- Filtro por dia específico no Painel, relatório e planilha
- Nome do desenvolvedor só na tela de login
- Viatura VAN 4051.5

## 2026.10.20 (20/10/2026)

- Quedas: atendimento imediato e registro do impacto na programação do dia
- Tipo de local: Processo passou a ser O.S
- Supervisor acessa só Programar, Baixas e Quedas
- Painel (dashboard) no lugar do Resumo
- Relatório: parciais e não executados em tabelas separadas, valores do contrato em R$
- Viaturas SKY 5074.0 e SPLINTER 5071.0 (reserva)
- Botões para abrir endereços no Google Maps

## 2026.10.19 (19/10/2026)

- Aba Quedas separada
- Lista só para visualização
- Relatório: impacto do não executado × feito no lugar
- Gráfico de árvores por dia com podas, extirpações e total
